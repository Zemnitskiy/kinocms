<template>
  <div class="content-wrapper">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: "AdminContent",
};
</script>
