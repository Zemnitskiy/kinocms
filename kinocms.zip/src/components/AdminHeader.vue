<template>
  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-light navbar-white">
    <div class="container">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link" href="#">
            <i class="fas fa-user fa-lg"></i>
            <span class="ml-2">Администратор</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#" role="button"
            ><i class="fas fa-power-off fa-lg"></i
          ></a>
        </li>
      </ul>
    </div>
  </nav>
  <!-- /.navbar -->
</template>

<script>
export default {
  name: "AdminHeader",
};
</script>
