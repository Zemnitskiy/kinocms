<template>
  <h1>Кинотеатры</h1>
</template>
