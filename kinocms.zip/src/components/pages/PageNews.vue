<template>
  <h1>Новости</h1>
</template>
