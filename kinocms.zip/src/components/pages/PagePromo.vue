<template>
  <h1>Акции</h1>
</template>
