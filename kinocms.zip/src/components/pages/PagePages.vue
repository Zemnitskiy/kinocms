<template>
  <h1>Страницы</h1>
</template>
