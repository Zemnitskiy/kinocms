<template>
  <h1>Рассылка</h1>
</template>
