<template>
  <h1>Статистика</h1>
</template>
